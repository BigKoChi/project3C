package com.example.demo.model.enums;

public enum MemberStatus {
	ACTIVE,    // 正常
    INACTIVE,  // 停用
    BANNED     // 封鎖
}

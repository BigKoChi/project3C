package com.example.demo.model.enums;

public enum EmployeeRole {
	ADMIN,     // 系統管理員
    MANAGER,   // 管理員／主管
    STAFF      // 一般員工
}

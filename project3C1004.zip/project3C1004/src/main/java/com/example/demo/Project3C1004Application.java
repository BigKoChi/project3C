package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project3C1004Application {

	public static void main(String[] args) {
		SpringApplication.run(Project3C1004Application.class, args);
	}

}
